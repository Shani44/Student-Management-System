<?php
class Course {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllCourses() {
        $stmt = $this->db->query("SELECT c.*, t.name AS teacher_name 
                                  FROM courses c 
                                  LEFT JOIN teachers t ON c.teacher_id = t.id");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addCourse($title, $description, $credits, $teacher_id) {
        $stmt = $this->db->prepare("INSERT INTO courses (title, description, credits, teacher_id) 
                                    VALUES (:title, :description, :credits, :teacher_id)");
        return $stmt->execute([
            'title' => $title,
            'description' => $description,
            'credits' => $credits,
            'teacher_id' => $teacher_id
        ]);
    }

    public function getTeacherCourses($teacher_id) {
        $stmt = $this->db->prepare("SELECT * FROM courses WHERE teacher_id = :teacher_id");
        $stmt->execute(['teacher_id' => $teacher_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>