<?php
class Enrollment {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getEnrollmentsByCourse($course_id) {
        $stmt = $this->db->prepare("SELECT e.*, s.name AS student_name 
                                    FROM enrollments e 
                                    JOIN students s ON e.student_id = s.id 
                                    WHERE e.course_id = :course_id");
        $stmt->execute(['course_id' => $course_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>