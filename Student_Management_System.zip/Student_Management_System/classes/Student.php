<?php
class Student {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getProfile($user_id) {
        $stmt = $this->db->prepare("SELECT * FROM students WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $user_id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function enrollCourse($student_id, $course_id) {
        $stmt = $this->db->prepare("INSERT INTO enrollments (student_id, course_id, date_enrolled) VALUES (:student_id, :course_id, CURDATE())");
        return $stmt->execute(['student_id' => $student_id, 'course_id' => $course_id]);
    }

    public function getEnrolledCourses($student_id) {
        $stmt = $this->db->prepare("SELECT c.*, e.date_enrolled, e.status 
                                    FROM enrollments e 
                                    JOIN courses c ON e.course_id = c.id 
                                    WHERE e.student_id = :student_id");
        $stmt->execute(['student_id' => $student_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>