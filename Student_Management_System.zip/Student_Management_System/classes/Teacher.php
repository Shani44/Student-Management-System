<?php
class Teacher {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllTeachers() {
        $stmt = $this->db->query("SELECT * FROM teachers");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addTeacher($name, $email, $phone, $subject) {
        $stmt = $this->db->prepare("INSERT INTO teachers (name, email, phone, subject) 
                                    VALUES (:name, :email, :phone, :subject)");
        return $stmt->execute([
            'name' => $name,
            'email' => $email,
            'phone' => $phone,
            'subject' => $subject
        ]);
    }
}
?>