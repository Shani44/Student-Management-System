<?php
class User {
    private $db;
    private $id;
    private $username;
    private $role;

    public function __construct($db) {
        $this->db = $db;
    }

    public function login($username, $password) {
        $stmt = $this->db->prepare("SELECT * FROM users WHERE username = :username");
        $stmt->execute(['username' => $username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $this->id = $user['id'];
            $this->username = $username;
            $this->role = $user['role'];
            return true;
        }
        return false;
    }

    public function getRole() {
        return $this->role;
    }

    public function getId() {
        return $this->id;
    }

    public function getAllUsers() {
        $stmt = $this->db->query("SELECT * FROM users");
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addUser($username, $password, $role, $email) {
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
        $stmt = $this->db->prepare("INSERT INTO users (username, password, role, email) VALUES (:username, :password, :role, :email)");
        return $stmt->execute([
            'username' => $username,
            'password' => $hashedPassword,
            'role' => $role,
            'email' => $email
        ]);
    }
}
?>