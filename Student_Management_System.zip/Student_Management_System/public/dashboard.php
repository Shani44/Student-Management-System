<?php
session_start();
require_once '../config/database.php';
require_once '../classes/User.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$db = (new Database())->connect();
$user = new User($db);
$role = $_SESSION['role'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Student Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../templates/header.php'; ?>
    <div class="container mt-5">
        <h2>Welcome, <?php echo $role; ?>!</h2>
        <?php if ($role == 'student'): ?>
            <?php include '../templates/student_dashboard.php'; ?>
        <?php elseif ($role == 'teacher'): ?>
            <?php include '../templates/teacher_dashboard.php'; ?>
        <?php elseif ($role == 'admin'): ?>
            <?php include '../templates/admin_dashboard.php'; ?>
        <?php endif; ?>
    </div>
    <?php include '../templates/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>