<?php
session_start();
require_once '../config/database.php';
require_once '../classes/Student.php';
require_once '../classes/Course.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'student') {
    header("Location: login.php");
    exit();
}

$db = (new Database())->connect();
$student = new Student($db);
$course = new Course($db);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'];
    $course_id = $_POST['course_id'];
    if ($student->enrollCourse($student_id, $course_id)) {
        $success = "Successfully enrolled in course!";
    } else {
        $error = "Failed to enroll in course.";
    }
}

$courses = $course->getAllCourses();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Enroll in Course</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <?php include '../templates/header.php'; ?>
    <div class="container mt-5">
        <h2>Enroll in a Course</h2>
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php elseif (isset($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form method="POST">
            <input type="hidden" name="student_id" value="<?php echo $_SESSION['user_id']; ?>">
            <div class="mb-3">
                <label for="course_id" class="form-label">Select Course</label>
                <select class="form-control" id="course_id" name="course_id" required>
                    <?php foreach ($courses as $c): ?>
                        <option value="<?php echo $c['id']; ?>"><?php echo $c['title']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Enroll</button>
        </form>
    </div>
    <?php include '../templates/footer.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>