CREATE DATABASE student_management_system;
USE student_management_system;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'teacher', 'student') NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    dob DATE,
    address TEXT,
    phone VARCHAR(20),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE teachers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(100)
);

CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    credits INT NOT NULL,
    teacher_id INT,
    FOREIGN KEY (teacher_id) REFERENCES teachers(id)
);

CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    date_enrolled DATE NOT NULL,
    status ENUM('active', 'completed', 'dropped') DEFAULT 'active',
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    UNIQUE KEY (student_id, course_id)
);

CREATE TABLE results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    marks INT NOT NULL,
    grade VARCHAR(2),
    remarks TEXT,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

-- Sample Data
INSERT INTO users (username, password, role, email) VALUES 
('admin', '$2y$10$6zM6z2b3f4k5j6h7i8j9k0', 'admin', 'admin@example.com'),
('teacher1', '$2y$10$6zM6z2b3f4k5j6h7i8j9k0', 'teacher', 'teacher1@example.com'),
('student1', '$2y$10$6zM6z2b3f4k5j6h7i8j9k0', 'student', 'student1@example.com');

INSERT INTO students (user_id, name, dob, address, phone) VALUES 
(3, 'Rana Muhammad Ahmad', '2000-01-01', '123 Street, City', '1234567890');

INSERT INTO teachers (name, email, phone, subject) VALUES 
('Prof. John', 'teacher1@example.com', '9876543210', 'Web Technologies');

INSERT INTO courses (title, description, credits, teacher_id) VALUES 
('Web Technologies', 'Learn web development', 3, 1);

INSERT INTO enrollments (student_id, course_id, date_enrolled) VALUES 
(1, 1, '2025-06-28');