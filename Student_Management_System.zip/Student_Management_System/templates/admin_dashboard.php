<div class="card">
    <div class="card-header">Admin Dashboard</div>
    <div class="card-body">
        <h5>Management Options</h5>
        <a href="manage_users.php" class="btn btn-primary">Manage Users</a>
        <a href="manage_courses.php" class="btn btn-primary">Manage Courses</a>
    </div>
</div>