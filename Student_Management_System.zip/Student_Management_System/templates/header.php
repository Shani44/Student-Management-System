<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="#">Student Management System</a>
        <div class="navbar-nav">
            <a class="nav-link" href="dashboard.php">Dashboard</a>
            <?php if (isset($_SESSION['role']) && $_SESSION['role'] == 'student'): ?>
                <a class="nav-link" href="enroll_course.php">Enroll Course</a>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] == 'teacher'): ?>
                <a class="nav-link" href="manage_courses.php">Manage Courses</a>
            <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] == 'admin'): ?>
                <a class="nav-link" href="manage_users.php">Manage Users</a>
                <a class="nav-link" href="manage_courses.php">Manage Courses</a>
            <?php endif; ?>
            <a class="nav-link" href="logout.php">Logout</a>
        </div>
    </div>
</nav>