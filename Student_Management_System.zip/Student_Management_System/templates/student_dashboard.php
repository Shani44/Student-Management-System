<?php
require_once '../classes/Student.php';
$student = new Student($db);
$profile = $student->getProfile($_SESSION['user_id']);
$courses = $student->getEnrolledCourses($profile['id']);
?>

<div class="card">
    <div class="card-header">Student Dashboard</div>
    <div class="card-body">
        <h5>Profile</h5>
        <p>Name: <?php echo $profile['name']; ?></p>
        <p>Phone: <?php echo $profile['phone']; ?></p>
        <h5>Enrolled Courses</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>Course Title</th>
                    <th>Date Enrolled</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><?php echo $c['title']; ?></td>
                        <td><?php echo $c['date_enrolled']; ?></td>
                        <td><?php echo $c['status']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="enroll_course.php" class="btn btn-primary">Enroll in Course</a>
    </div>
</div>