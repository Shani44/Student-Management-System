<?php
require_once '../classes/Course.php';
$course = new Course($db);
$courses = $course->getTeacherCourses($_SESSION['user_id']);
?>

<div class="card">
    <div class="card-header">Teacher Dashboard</div>
    <div class="card-body">
        <h5>Assigned Courses</h5>
        <table class="table">
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Credits</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($courses as $c): ?>
                    <tr>
                        <td><?php echo $c['title']; ?></td>
                        <td><?php echo $c['credits']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="manage_courses.php" class="btn btn-primary">Manage Courses</a>
    </div>
</div>